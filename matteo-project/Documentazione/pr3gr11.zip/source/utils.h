#include <string.h>

#ifndef LASD_2017_UTILS_H
#define LASD_2017_UTILS_H

void clearBuffer();
int getIntFromInput(int *data);
int getFloatFromInput(float *f);

#endif //LASD_2017_UTILS_H
