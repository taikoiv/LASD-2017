#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "abr.h"

#define X 1
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

void stampa(tree *t){
	if(t!=NULL){
		printf("%d  ", t->info);
		stampa(t->left);
		stampa(t->right);
	}
}

int main() {
	srand(time(NULL));
<<<<<<< HEAD
	tree *head, *other;
	//other = newRandomBst(10);
	head = newRandomBst(30);
	printf("altezza : %d\n\n", height(head)); 
	stampa(head);
	printf("\n-------------------------------------------------\n");
	printBst(head);
=======
	tree *head;
	int c,i;
	float avg=0;
	printf("0 to test random insert\n");
	scanf("%d",&c);
	if(c==0){
		tree *trees[X];
		for(i=0;i<X;i++){
			trees[i]=newRandomTree(131072);
			c=height(trees[i]);
			avg+=c;
			printf("ALBERO %d - ALTEZZA = %d\n",i+1,c);
		}
		printf("ALTEZZA MEDIA FLOAT : %f - INT : %d",avg/X,(int)avg/X);
	}
	else{
		head = newRandomTree(10);
	    print(head, 0);
	}
>>>>>>> origin/master
	return 0;
}
